import picommon
import piflow

class flow_web:
  press_status_str = [  "Unconfigured",
                        "Idle",
                        "Active",
                        "Error"
                     ]

  flow_status_str  = [  "Unconfigured",
                        "Idle",
                        "Active",
                        "Error"
                     ]

  ctrl_mode_str    = [  "Off",
                        "Pressure Open Loop",
                        "Pressure Closed Loop",
                        "Flow Closed Loop"
                     ]

  def __init__( self, port ):
    self.flow = piflow.PiFlow( port, 0.1 )
    
    self.status_text            = [ ("Init")  for i in range(self.flow.NUM_CONTROLLERS) ]
    self.pressure_mbar_text     = [ ("")      for i in range(self.flow.NUM_CONTROLLERS) ]
    self.pressure_mbar_targets  = [ (0.00)    for i in range(self.flow.NUM_CONTROLLERS) ]
    self.flow_ul_hr_text        = [ ("")      for i in range(self.flow.NUM_CONTROLLERS) ]
    self.control_modes          = [ (0)       for i in range(self.flow.NUM_CONTROLLERS) ]
    self.control_modes_text     = [ ("")      for i in range(self.flow.NUM_CONTROLLERS) ]
    
    valid, id, id_valid = self.flow.get_id()
    print( "ID OK:{}, ID={}".format( id_valid, id ) )
    self.enabled = valid and id_valid
    
    self.get_pressure_targets()
    self.get_control_modes()

  def get_pressure_targets( self ):
    valid, pressures_mbar_targets = self.flow.get_pressure_target()
    if valid:
      self.pressure_mbar_targets = pressures_mbar_targets

  def get_control_modes( self ):
    valid, control_modes = self.flow.get_control_modes()
    if valid:
      self.control_modes = control_modes
      self.control_modes_text = [ (self.ctrl_mode_str[control_mode]) for control_mode in control_modes ]

  def set_pressure( self, index, pressure_mbar ):
    try:
      pressure = int( pressure_mbar )
      self.flow.set_pressure( [index], [pressure] )
      self.get_pressure_targets()
    except:
      pass
  
  def set_control_mode( self, index, control_mode ):
    try:
      self.flow.set_control_mode( [index], [control_mode] )
      self.get_control_modes()
    except:
      pass
  
  def set_pid_running( self, run ):
    try:
      self.holder.set_pid_running( run )
    except:
      pass
  
  def update( self ):
    if not self.enabled:
      self.status_text = [ ( "Offline" ) for i in range (self.flow.NUM_CONTROLLERS) ]
    else:
      valid = True
      
      okay = valid
      valid, pressures_actual = self.flow.get_pressure_actual();
      if valid:
        self.pressures_actual = pressures_actual
      okay = okay and valid
      
      valid, flows_actual = self.flow.get_flow_actual();
      if valid:
        self.flows_actual = flows_actual
      okay = okay and valid
      
      if not okay:
        self.status_text = [ ( "Connection Error" ) for i in range (self.flow.NUM_CONTROLLERS) ]
      else:
          try:
            self.status_text = [ ( "Connected" ) for i in range (self.flow.NUM_CONTROLLERS) ]
          except:
            pass
      
      try:
        self.pressure_mbar_text = [ ( "{} / {}".format( round( self.pressures_actual[i], 2 ), round( self.pressure_mbar_targets[i], 2 ) ) ) for i in range (self.flow.NUM_CONTROLLERS) ]
        self.flow_ul_hr_text = [ ( "{}".format( round( self.flows_actual[i], 2 ) ) ) for i in range (self.flow.NUM_CONTROLLERS) ]
      except:
        pass
       
    try:
      pass
    except:
      pass
